from django.db import models
from django.utils import timezone
from django.utils.text import slugify

from sm_core.user_auth.models import User

# Create your models here.
class App(models.Model):
  app_name = models.CharField(max_length=50, unique=True)

  def __str__(self):
      return self.app_name


class Plan(models.Model):
  plan_name = models.CharField(max_length=50, unique=True)
  max_number_members = models.IntegerField()
  cloud_storage = models.IntegerField()
  apps = models.ManyToManyField(App, related_name='related_apps')

  def __str__(self):
    return self.plan_name


class Company(models.Model):
  company_avatar = models.ImageField(upload_to="company_avatars/")
  company_name = models.CharField(max_length=100, unique=True)
  company_slug = models.SlugField(max_length=150, unique=True)
  company_description = models.CharField(max_length=500)
  company_email = models.EmailField(blank=True, null=True)
  company_address = models.CharField(max_length=50,blank=True, null=True)
  company_state = models.CharField(max_length=50,blank=True, null=True)
  company_town = models.CharField(max_length=50,blank=True, null=True)
  company_zip = models.CharField(max_length=50,blank=True, null=True)
  company_Bank_name = models.CharField(max_length=50,blank=True, null=True)
  company_Bank_country = models.CharField(max_length=50,blank=True, null=True)
  company_IBAN = models.CharField(max_length=50,blank=True, null=True)
  company_SWIFT = models.CharField(max_length=50,blank=True, null=True)
  domain_name = models.CharField(max_length=200)
  plan = models.ForeignKey(Plan, on_delete=models.CASCADE, related_name='plan', blank=True, null=True)
  created_at = models.DateTimeField(auto_now_add=True)

  def __str__(self):      
    return self.company_name
  
  def save(self, *args, **kwargs):
        if not self.company_slug:
            self.company_slug = slugify(self.company_name)
        super().save(*args, **kwargs)
  

class PermissionGroup(models.Model):
  permission_group_name = models.CharField(max_length=50, unique=True)

  def __str__(self):
      return self.permission_group_name
  

class Permission(models.Model):
  permission_name = models.CharField(max_length=50, unique=True)
  permission_group = models.ForeignKey(PermissionGroup, on_delete=models.CASCADE, related_name='permission_group')

  def __str__(self):
      return self.permission_name


class Role(models.Model):
  role_name = models.CharField(max_length=50)
  company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='company_role')
  permissions = models.ManyToManyField(Permission)

  def __str__(self):
      if self.role_name:
          return self.role_name
      return super().__str__()


class ProfileModification(models.Model):
  user = models.ForeignKey(
    User,
    on_delete=models.CASCADE,
    related_name='profile_modifications',
    verbose_name='User'
  )
  modified_by = models.ForeignKey(
    Role,
    on_delete=models.SET_NULL,
    null=True,
    related_name='profile_modifications_created',
    verbose_name='Modified By'
  )
  modified_date = models.DateTimeField(default=timezone.now, verbose_name='Modification Date',null=True)
  modified_data = models.JSONField(default=dict, verbose_name='Modified Data',null=True)

  class Meta:
    verbose_name = 'profile modification'
    verbose_name_plural = 'profile modifications'


class Client(models.Model):
  """
    User subtype with specific fields and properties
    """
  user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='client')
  company = models.ForeignKey(Company, on_delete=models.CASCADE, related_name='company_client')

  # New fields for additional client information
  avatar = models.ImageField(upload_to="client_avatars/")
  full_name = models.CharField(max_length=255, blank=True, null=True)
  address = models.CharField(max_length=255, blank=True, null=True)
  phone_number = models.CharField(max_length=20, blank=True, null=True)
  bank_name = models.CharField(max_length=255, blank=True, null=True)
  country = models.CharField(max_length=255, blank=True, null=True)
  iban = models.CharField(max_length=30, blank=True, null=True)
  swift_code = models.CharField(max_length=30, blank=True, null=True)
  
  class Meta:
        verbose_name = 'client'
        verbose_name_plural = 'clients'


class Employee(models.Model):
  """
    User subtype with specific fields and properties
    """
  user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='employee')
  role = models.ForeignKey(Role, on_delete=models.SET_NULL, related_name='user_role', null=True,default=1)


class Profile(models.Model):
  status_choices = [
        ('online', 'Online'),
        ('away', 'Away'),
        ('busy', 'Do not Disturb'),
        ('offline', 'Offline'),
  ]

  external_email = models.EmailField(unique=True, null=True)
  first_name = models.CharField(max_length=30, blank=True)
  last_name = models.CharField(max_length=50, blank=True)
  job_title = models.CharField(max_length=100, default='')
  date_of_birth = models.DateTimeField(default=timezone.now)
  phone_number = models.CharField(max_length=20, blank=True)
  status = models.CharField(max_length=10, choices=status_choices,default="Online")
  avatar = models.ImageField(upload_to="employee_avatars/", blank=True, null= True)
  country = models.CharField(max_length=100, default='')
  language = models.CharField(max_length=100, default='')
  skype = models.CharField(max_length=100, default='')

  employee = models.ForeignKey(Employee, on_delete=models.CASCADE, related_name='employee_profile')
  profilemodification = models.ManyToManyField(ProfileModification, related_name='employeemodification',null=True, blank=True)

  def __str__(self):
    full_name = f"{self.first_name} {self.last_name}"
    return full_name.strip()  # Trim leading/trailing spaces