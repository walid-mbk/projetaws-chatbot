from django.contrib import admin
from . import models

# Register your models here.
class PermissionAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'permission_name',
        'permission_group',
    )


class PermissionGroupAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'permission_group_name',
    )


class RoleAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'role_name',
        'company'
    )
    list_filter = (
        'company',      
    )
    raw_id_fields = ('company',)


class ProfileAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'employee',
        'job_title',
    )

class ProfileModificationAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'user',
        'modified_by', 
    )


class EmployeeAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'user',
        'role'
    )
    list_filter = (
        'user',
        'role'       
    )
    raw_id_fields = ('user','role')


class ClientAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'user',
    )
    list_filter = (
        'user',      
    )
    raw_id_fields = ('user',)


class AppAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'app_name'
    )


class PlanAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'plan_name',
        'max_number_members',
        'cloud_storage'
    )


class CompanyAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'company_name',
        'plan',
        'created_at',
    )
    list_filter = (
        'company_name',
    )

def register_models(admin_class_list):
    for model, admin_class in admin_class_list:
        admin.site.register(model, admin_class)

register_models([
    (models.Permission, PermissionAdmin),
    (models.PermissionGroup, PermissionGroupAdmin),
    (models.Role, RoleAdmin),
    (models.Profile, ProfileAdmin),
    (models.Employee, EmployeeAdmin),
    (models.Client, ClientAdmin),
    (models.App, AppAdmin),
    (models.Plan, PlanAdmin),
    (models.Company, CompanyAdmin),
    (models.ProfileModification, ProfileModificationAdmin),
])
