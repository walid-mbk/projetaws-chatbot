from django.contrib import admin
from . import models

# Register your models here.
admin.site.register(models.Event)
admin.site.register(models.ChatRoom)
admin.site.register(models.ChatMessage)
admin.site.register(models.Inbox)
admin.site.register(models.DevelopmentEmail)
admin.site.register(models.InboxEmail)