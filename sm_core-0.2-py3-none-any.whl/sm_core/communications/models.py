from django.db import models
from django.utils import timezone
from django.db import models
from django.urls import reverse

from sm_core.management.models import Employee

# Create your models here.
class Event(models.Model):
    PERSONAL = 1
    BUSINESS = 2
    FAMILY = 3
    HOLIDAY = 4
    ETC = 5
    MY_CHOICES = (
        (PERSONAL, 'Personal'),
        (BUSINESS, 'Business'),
        (FAMILY, 'Family'),
        (HOLIDAY, 'Holiday'),
        (ETC, 'Etc'),
    )
    user =  models.ManyToManyField(Employee, related_name='events_created')
    title = models.CharField(default='', max_length=200)
    description = models.TextField(default='')
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(default=timezone.now)
    event_url = models.TextField(default='')
    calendar = models.PositiveSmallIntegerField(
        default=1,  
        choices=MY_CHOICES,
        blank=True,
        null=True,
    )
    all_day = models.BooleanField(default=False)
    guests = models.ManyToManyField(Employee, related_name='events_invited')

    class Meta:
        ordering = ['-title']

    def __str__(self):
        return self.title if self.title else f"Event {self.id}"  

    def get_html_url(self):
        url = reverse('cal:event_edit', args=(self.id,))
        return f'<a href="{url}"> {self.title} </a>'
    

class ChatRoom(models.Model):
    name = models.CharField(max_length=255, unique=True)
    users = models.ManyToManyField(Employee, related_name='chat_rooms')
    created_at = models.DateTimeField(auto_now_add=True)
    chat_history = models.TextField(blank=True)
    last_message = models.ForeignKey('ChatMessage', on_delete=models.SET_NULL, null=True, blank=True, related_name='room_last_message')

    def __str__(self):
        user_list = ", ".join(str(user) for user in self.users.all())
        return f"Chat room with users: {user_list}"


class ChatMessage(models.Model):
    sender = models.ForeignKey(Employee, on_delete=models.CASCADE)
    room = models.ForeignKey(ChatRoom, on_delete=models.CASCADE, related_name='messages')
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.sender.username} - {self.timestamp}"
    

class Inbox(models.Model):
    email = models.EmailField(unique=True)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created']

    def __str__(self):
        return self.email

    def get_unread_email_number(self):

        return InboxEmail.objects.filter(inbox=self, read=False).count()
  
    '''def get_absolute_url(self):
        try:
            return reverse(
                'developmentEmailDashboard:inbox_view', kwargs={'email': self.email}
            )
        except NoReverseMatch:
            pass'''
    def get_absolute_url(self):
        return reverse('inbox_detail', kwargs={'pk': self.pk})
        # Handle script prefix manually because we bypass reverse()
        return iri_to_uri(get_script_prefix().rstrip('/') + self.url)


# model for the actual email message
class DevelopmentEmail(models.Model):
    types = (
        ('casual', 'Casual'),
        ('appreciative', 'Appreciative'),
        ('meeting_attending', 'Meeting Attending'),
        ('formal', 'Formal'),
        ('informative', 'Informative'),
        ('funny', 'Funny')
    )

    folders = (
        ('inbox', 'Inbox'),
        ('sent', 'Sent'),
        ('draft', 'Draft'),
        ('starred', 'Starred'),
        ('spam', 'Spam'),
        ('trash', 'Trash'),
    )

    labels = (
        ('personal', 'Personal'),
        ('company', 'Company'),
        ('important', 'Important'),
        ('private', 'Private'),
    )

    subject = models.CharField(max_length=200)
    body = models.TextField()
    from_email = models.EmailField()
    extra_headers = models.CharField(max_length=255, blank=True, default='')
    to = models.EmailField()
    bcc = models.CharField(max_length=255, blank=True, default='')
    cc = models.CharField(max_length=255, blank=True, default='')
    reply_to = models.TextField()
    email_type = models.PositiveSmallIntegerField(
        default=1,
        choices=types,
        blank=True,
        null=True,
    )
    attachments = models.FileField(upload_to='email_attachments/', blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)
    folder = models.PositiveSmallIntegerField(
        default=1,
        choices=folders
    )
    label = models.PositiveSmallIntegerField(
        choices=labels,
        blank=True,
        null=True,
    )

    class Meta:
        ordering = ['-created']

    def __str__(self):
        return f'from: {self.from_email} | {self.subject[:20]}...'


# model for the unique email the user deletes/reads/sends etc
class InboxEmail(models.Model):
    inbox = models.ForeignKey(Inbox, on_delete=models.CASCADE, related_name='sent_emails')
    email = models.ForeignKey(Employee, on_delete=models.CASCADE)
    content = models.TextField(max_length=255, blank=True, default='')

    read = models.BooleanField(default=False)
    is_sender = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created']
