from django.contrib import admin
from . import models

# Register your models here.
class UserAdmin(admin.ModelAdmin):

    list_display = (
        'id',
        'password',
        'last_login',
        'user_id',
        'username',
        'email',
        'date_joined',
        'is_active',
        'is_recognized',
        'is_staff',
        'is_superuser',
        'is_deleted',
        'created_date',
        'modified_date',
        'created_by',
        'modified_by',
    )
    list_filter = (
        'email',
        'username',
        'is_superuser'       
    )


def register_models(admin_class_list):
    for model, admin_class in admin_class_list:
        admin.site.register(model, admin_class)

register_models([
    (models.User, UserAdmin),
])