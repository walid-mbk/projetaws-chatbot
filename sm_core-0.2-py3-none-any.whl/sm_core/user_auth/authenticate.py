
from django.conf import settings
from django.middleware import csrf
from rest_framework.response import Response
from rest_framework_simplejwt import tokens, serializers 
from rest_framework_simplejwt.exceptions import InvalidToken
from rest_framework_simplejwt import authentication as jwt_authentication
from rest_framework import authentication, exceptions as rest_exceptions

def refresh_token(request):
    refresh_token = request.COOKIES.get(settings.SIMPLE_JWT['AUTH_COOKIE_REFRESH'], None)
    if refresh_token:
        try:
            refresh = tokens.RefreshToken(token=refresh_token)
            serializer = serializers.TokenRefreshSerializer(data={'refresh': str(refresh)})
            serializer.is_valid(raise_exception=True)
            new_tokens = serializer.data

            new_csrf_token = csrf.get_token(request)
                
            if new_tokens['access'] is not None:
                # Update request with new tokens and CSRF token after successful refresh
                request.COOKIES[settings.SIMPLE_JWT['AUTH_COOKIE']] = new_tokens['access']
                request.COOKIES[settings.SIMPLE_JWT['AUTH_COOKIE_REFRESH']] = new_tokens['refresh']
                request.COOKIES['csrftoken'] = new_csrf_token
                request.META['TOKEN_REFRESHED'] = True

                return new_tokens['access'], new_csrf_token
            else:
                return None, None
        except:
            return None, None
    else:
        return None, None


def enforce_csrf(request):
    check = authentication.CSRFCheck(request)
    reason = check.process_view(request, None, (), {})
    if reason:
      raise rest_exceptions.PermissionDenied('CSRF Failed: %s' % reason)


class CustomAuthentication(jwt_authentication.JWTAuthentication):
    def authenticate(self, request):
        header = self.get_header(request) or None
        raw_token = request.COOKIES.get(settings.SIMPLE_JWT['AUTH_COOKIE']) or None 
        csrf_token = request.COOKIES.get("csrftoken") or None
        
        if raw_token is None:
            if header is None:
                return None
            else:
                raw_token = self.get_raw_token(header)

        if request.method not in ('GET', 'HEAD', 'OPTIONS', 'TRACE'):
            if csrf_token is None:
                raw_token, csrf_token = refresh_token(request)
                if raw_token is None:
                    raise rest_exceptions.PermissionDenied('Refresh token is invalid or expired')

            request.META['HTTP_X_CSRFTOKEN'] = csrf_token

        try:
            validated_token = self.get_validated_token(raw_token)
        except InvalidToken as e:
            if isinstance(e.args[0], dict) and 'messages' in e.args[0]:
                for message in e.args[0]['messages']:
                    if 'message' in message and message['message'] == 'Token is invalid or expired':
                        new_access_token, csrf_token = refresh_token(request)
                        if new_access_token is not None:
                            validated_token = self.get_validated_token(new_access_token)
                        else:
                            raise rest_exceptions.PermissionDenied('Refresh token is invalid or expired')

        enforce_csrf(request)
        return self.get_user(validated_token), validated_token