from django.db import models

import uuid
from django.db import models
from django.contrib.auth.base_user import AbstractBaseUser

from .managers import CustomUserManager

# Create your models here.
class User(AbstractBaseUser):
  user_id = models.UUIDField(unique=True, editable=False, default=uuid.uuid4, verbose_name='Public identifier')
  email = models.EmailField(unique=True)
  username = models.CharField(max_length=30, default='')
  date_joined = models.DateTimeField(auto_now_add=True)
  is_active = models.BooleanField(default=True)
  is_recognized = models.BooleanField(default=False) 
  is_staff = models.BooleanField(default=False)
  is_superuser = models.BooleanField(default=False)
  is_deleted = models.BooleanField(default=False)
  created_date = models.DateTimeField(auto_now_add=True)
  modified_date = models.DateTimeField(auto_now=True)
  created_by = models.EmailField(default='system')
  modified_by = models.EmailField(default='system')

  USERNAME_FIELD = 'email'
  REQUIRED_FIELDS = []

  objects = CustomUserManager()

  def __str__(self):
        return self.email
  
  def has_perm(self, perm, obj=None):
    return self.is_superuser

  def has_module_perms(self, app_label):
    return self.is_superuser
  
  class Meta:
        verbose_name = 'user'
        verbose_name_plural = 'users'